<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/bootstrap-grid.css">
    <link rel="stylesheet" href="css/bootstrap-reboot.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
       <link rel="stylesheet" href="css/style.css">
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

    <footer>
        <p>Liesbet Van Seghbroeck</p>
    </footer>
</body>
</html>