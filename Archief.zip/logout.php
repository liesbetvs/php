<?php
session_start();
unset($_SESSION['todo_login']);
header("location: index.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logout</title>
</head>
<body>
    
</body>
</html>